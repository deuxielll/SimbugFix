#!/system/bin/sh
ui_print "⚡ Installing RILResetter..."
ui_print "🔁 Will reset RIL every 3 hours."
